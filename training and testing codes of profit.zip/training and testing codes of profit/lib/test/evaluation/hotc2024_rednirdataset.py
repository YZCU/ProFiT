import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
class hotc2024_rednirDataset(BaseDataset):

    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.hotc2024_rednir_path
        self.sequence_info_list = self._get_sequence_info_list()
    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])
    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']
        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']
        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]
        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])  
        
        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64,
                                      backend='numpy')  
        return Sequence(sequence_info['name'], frames, 'hotc2024_rednir', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])
    def __len__(self):
        return len(self.sequence_info_list)
    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "backpack4", "path": "backpack4", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "backpack4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "ball&mirror10", "path": "ball&mirror10", "startFrame": 1, "endFrame": 550, "nz": 4, "ext": "png",
             "anno_path": "ball&mirror10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cards6", "path": "cards6", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "cards6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cloth3", "path": "cloth3", "startFrame": 1, "endFrame": 350, "nz": 4, "ext": "png",
             "anno_path": "cloth3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cranberries7", "path": "cranberries7", "startFrame": 1, "endFrame": 500, "nz": 4, "ext": "png",
             "anno_path": "cranberries7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "dice3", "path": "dice3", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "dice3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "drone4", "path": "drone4", "startFrame": 1, "endFrame": 325, "nz": 4, "ext": "png",
             "anno_path": "drone4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "dronecam4", "path": "dronecam4", "startFrame": 1, "endFrame": 460, "nz": 4, "ext": "png",
             "anno_path": "dronecam4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "droneshow2", "path": "droneshow2", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "droneshow2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "duck4", "path": "duck4", "startFrame": 1, "endFrame": 375, "nz": 4, "ext": "png",
             "anno_path": "duck4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "football1", "path": "football1", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "png",
             "anno_path": "football1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "football2", "path": "football2", "startFrame": 1, "endFrame": 325, "nz": 4, "ext": "png",
             "anno_path": "football2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "leaves5", "path": "leaves5", "startFrame": 1, "endFrame": 875, "nz": 4, "ext": "png",
             "anno_path": "leaves5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "officechair2", "path": "officechair2", "startFrame": 1, "endFrame": 775, "nz": 4, "ext": "png",
             "anno_path": "officechair2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "oranges5", "path": "oranges5", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "oranges5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pills5", "path": "pills5", "startFrame": 1, "endFrame": 550, "nz": 4, "ext": "png",
             "anno_path": "pills5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool12", "path": "pool12", "startFrame": 1, "endFrame": 600, "nz": 4, "ext": "png",
             "anno_path": "pool12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool9", "path": "pool9", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "pool9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rainystreet12", "path": "rainystreet12", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "png",
             "anno_path": "rainystreet12/groundtruth_rect.txt", "object_class": "person"},
            {"name": "whitecup2", "path": "whitecup2", "startFrame": 1, "endFrame": 437, "nz": 4, "ext": "png",
             "anno_path": "whitecup2/groundtruth_rect.txt", "object_class": "person"}
        ]
        return sequence_info_list
