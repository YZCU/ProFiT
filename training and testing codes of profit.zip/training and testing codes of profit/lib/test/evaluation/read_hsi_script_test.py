import numpy as np
from PIL import Image
import torch
import os
import cv2
def X2Cube(img, hsi_path=None, bands=81, skips=[9, 9]):
    B = skip = skips
    img = np.asarray(img)
    M, N = img.shape
    col_extent = N - B[1] + 1
    row_extent = M - B[0] + 1
    start_idx = np.arange(B[0])[:, None] * N + np.arange(B[1])
    didx = M * N * np.arange(1)
    start_idx = (didx[:, None] + start_idx.ravel()).reshape((-1, B[0], B[1]))
    offset_idx = np.arange(row_extent)[:, None] * N + np.arange(col_extent)
    out = np.take(img, start_idx.ravel()[:, None] + offset_idx[::skip[0], ::skip[1]].ravel())
    out = np.transpose(out)
    img = out.reshape(M // skip[0], N // skip[1], bands)
    img = img.astype(np.float32)
    channel_mean = np.mean(img, axis=(0, 1))
    if True:
        channel_max = min(channel_mean.mean() * 3, 511)
        img[img > channel_max] = channel_max
    channel_max = np.where(channel_max == 0, 1, channel_max)
    img /= channel_max
    img *= 255
    img = img.astype(np.uint8)
    img_fc = img[:, :, np.linspace(0, bands - 1, 5, dtype=int)[1:4]]
    if 'rednir' in hsi_path:
        img_hsi = img[:, :, 0:15]
    else:
        img_hsi = img[:, :, np.linspace(0, bands - 1, 15, dtype=int)]
    fused_img = cv2.merge((img_fc, img_hsi))
    return fused_img
def read_hsi(hsi_path: str, bandss=81, skipss=[9, 9]):
    hsi_image = Image.open(hsi_path)
    hsi_image = X2Cube(hsi_image, hsi_path=hsi_path, bands=bandss, skips=skipss)
    return hsi_image
