import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
class hotc2023_rednirDataset(BaseDataset):
    """ OTB-2015 dataset
    Publication:
        Object Tracking Benchmark
        Wu, Yi, Jongwoo Lim, and Ming-hsuan Yan
        TPAMI, 2015
        http://faculty.ucmerced.edu/mhyang/papers/pami15_tracking_benchmark.pdf
    Download the dataset from http://cvlab.hanyang.ac.kr/tracker_benchmark/index.html
    """
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.hotc2023_rednir_path
        self.sequence_info_list = self._get_sequence_info_list()
    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])
    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']
        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']
        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]
        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])  
        
        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64,
                                      backend='numpy')  
        return Sequence(sequence_info['name'], frames, 'hotc2023_rednir', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])
    def __len__(self):
        return len(self.sequence_info_list)
    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "ball&mirror9", "path": "ball&mirror9", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "ball&mirror9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cards16", "path": "cards16", "startFrame": 1, "endFrame": 375, "nz": 4, "ext": "png",
             "anno_path": "cards16/groundtruth_rect.txt", "object_class": "person"},
            {"name": "cards19", "path": "cards19", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "cards19/groundtruth_rect.txt", "object_class": "person"},
            {"name": "dice2", "path": "dice2", "startFrame": 1, "endFrame": 450, "nz": 4, "ext": "png",
             "anno_path": "dice2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "duck5", "path": "duck5", "startFrame": 1, "endFrame": 325, "nz": 4, "ext": "png",
             "anno_path": "duck5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "partylights6", "path": "partylights6", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "partylights6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool10", "path": "pool10", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "pool10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "pool11", "path": "pool11", "startFrame": 1, "endFrame": 250, "nz": 4, "ext": "png",
             "anno_path": "pool11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rainystreet10", "path": "rainystreet10", "startFrame": 1, "endFrame": 275, "nz": 4, "ext": "png",
             "anno_path": "rainystreet10/groundtruth_rect.txt", "object_class": "person"},
            {"name": "rainystreet16", "path": "rainystreet16", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "png",
             "anno_path": "rainystreet16/groundtruth_rect.txt", "object_class": "person"},
            {"name": "whitecup1", "path": "whitecup1", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "png",
             "anno_path": "whitecup1/groundtruth_rect.txt", "object_class": "person"}
        ]
        return sequence_info_list
