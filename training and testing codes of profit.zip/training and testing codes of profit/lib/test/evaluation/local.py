import os
from lib.test.evaluation.environment import EnvSettings
current_path = os.getcwd()
target_path = os.path.dirname(current_path)
def local_env_settings():
    settings = EnvSettings()
    base_dir = target_path
    # --
    settings.hotc2020_path = r'G:\1datasets\48hotc2020\test_35\HSI'
    settings.hotc2023_nir_path = r'G:\1datasets\0hotc2023\val\NIR'
    settings.hotc2023_rednir_path = r'G:\1datasets\0hotc2023\val\RedNIR'
    settings.hotc2023_vis_path = r'G:\1datasets\0hotc2023\val\VIS'
    settings.hotc2024_nir_path = r'G:\1datasets\0hotc2024\val\NIR'
    settings.hotc2024_rednir_path = r'G:\1datasets\0hotc2024\val\RedNIR'
    settings.hotc2024_vis_path = r'G:\1datasets\0hotc2024\val\VIS'
    settings.msvt_path = r'G:\1datasets\0msvt\test\OTB100'
    settings.mssot_path = r'G:\1datasets\0mssot\test\OTB100'
    # --
    settings.prj_dir = settings.save_dir = base_dir
    settings.results_path = fr'{base_dir}\output\results'
    return settings
