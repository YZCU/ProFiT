import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
class mssotDataset(BaseDataset):
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.mssot_path
        self.sequence_info_list = self._get_sequence_info_list()
    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])
    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']
        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']
        frames = ['{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(base_path=self.base_path,
                                                                           sequence_path=sequence_path, frame=frame_num,
                                                                           nz=nz, ext=ext) for frame_num in
                  range(start_frame + init_omit, end_frame + 1)]
        anno_path = '{}/{}'.format(self.base_path, sequence_info['anno_path'])
        ground_truth_rect = load_text(str(anno_path), delimiter=(',', None), dtype=np.float64,
                                      backend='numpy')
        return Sequence(sequence_info['name'], frames, 'mssot', ground_truth_rect[init_omit:, :],
                        object_class=sequence_info['object_class'])
    def __len__(self):
        return len(self.sequence_info_list)
    def _get_sequence_info_list(self):
        sequence_info_list = [
            {"name": "airplane-0", "path": "airplane-0/imgs/", "startFrame": 1, "endFrame": 290, "nz": 4, "ext": "tif",
             "anno_path": "airplane-0/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane-1", "path": "airplane-1/imgs/", "startFrame": 1, "endFrame": 240, "nz": 4, "ext": "tif",
             "anno_path": "airplane-1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane-11", "path": "airplane-11/imgs/", "startFrame": 1, "endFrame": 300, "nz": 4,
             "ext": "tif", "anno_path": "airplane-11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane-2", "path": "airplane-2/imgs/", "startFrame": 1, "endFrame": 70, "nz": 4, "ext": "tif",
             "anno_path": "airplane-2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane-20", "path": "airplane-20/imgs/", "startFrame": 1, "endFrame": 95, "nz": 4, "ext": "tif",
             "anno_path": "airplane-20/groundtruth_rect.txt", "object_class": "person"},
            {"name": "airplane-21", "path": "airplane-21/imgs/", "startFrame": 1, "endFrame": 153, "nz": 4,
             "ext": "tif", "anno_path": "airplane-21/groundtruth_rect.txt", "object_class": "person"},
            {"name": "basketball-0", "path": "basketball-0/imgs/", "startFrame": 1, "endFrame": 2000, "nz": 4,
             "ext": "tif", "anno_path": "basketball-0/groundtruth_rect.txt", "object_class": "person"},
            {"name": "basketball-1", "path": "basketball-1/imgs/", "startFrame": 1, "endFrame": 800, "nz": 4,
             "ext": "tif", "anno_path": "basketball-1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle-1n", "path": "bicycle-1n/imgs/", "startFrame": 1, "endFrame": 382, "nz": 4, "ext": "tif",
             "anno_path": "bicycle-1n/groundtruth_rect.txt", "object_class": "person"},
            {"name": "bicycle-7n", "path": "bicycle-7n/imgs/", "startFrame": 1, "endFrame": 119, "nz": 4, "ext": "tif",
             "anno_path": "bicycle-7n/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat-11", "path": "boat-11/imgs/", "startFrame": 1, "endFrame": 400, "nz": 4, "ext": "tif",
             "anno_path": "boat-11/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat-13", "path": "boat-13/imgs/", "startFrame": 1, "endFrame": 150, "nz": 4, "ext": "tif",
             "anno_path": "boat-13/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat-3", "path": "boat-3/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "boat-3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat-4", "path": "boat-4/imgs/", "startFrame": 1, "endFrame": 70, "nz": 4, "ext": "tif",
             "anno_path": "boat-4/groundtruth_rect.txt", "object_class": "person"},
            {"name": "boat-6", "path": "boat-6/imgs/", "startFrame": 1, "endFrame": 300, "nz": 4, "ext": "tif",
             "anno_path": "boat-6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-15", "path": "car-15/imgs/", "startFrame": 1, "endFrame": 201, "nz": 4, "ext": "tif",
             "anno_path": "car-15/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-16", "path": "car-16/imgs/", "startFrame": 1, "endFrame": 191, "nz": 4, "ext": "tif",
             "anno_path": "car-16/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-24", "path": "car-24/imgs/", "startFrame": 1, "endFrame": 511, "nz": 4, "ext": "tif",
             "anno_path": "car-24/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-25", "path": "car-25/imgs/", "startFrame": 1, "endFrame": 721, "nz": 4, "ext": "tif",
             "anno_path": "car-25/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-26", "path": "car-26/imgs/", "startFrame": 1, "endFrame": 149, "nz": 4, "ext": "tif",
             "anno_path": "car-26/groundtruth_rect.txt", "object_class": "person"},
            {"name": "car-27", "path": "car-27/imgs/", "startFrame": 1, "endFrame": 734, "nz": 4, "ext": "tif",
             "anno_path": "car-27/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double-6", "path": "double-6/imgs/", "startFrame": 1, "endFrame": 80, "nz": 4, "ext": "tif",
             "anno_path": "double-6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double-8", "path": "double-8/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "double-8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "double-9", "path": "double-9/imgs/", "startFrame": 1, "endFrame": 473, "nz": 4, "ext": "tif",
             "anno_path": "double-9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublebasketball-0", "path": "doublebasketball-0/imgs/", "startFrame": 1, "endFrame": 1900,
             "nz": 4, "ext": "tif", "anno_path": "doublebasketball-0/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar-1", "path": "doublecar-1/imgs/", "startFrame": 1, "endFrame": 196, "nz": 4,
             "ext": "tif", "anno_path": "doublecar-1/groundtruth_rect.txt", "object_class": "person"},
            {"name": "doublecar-9", "path": "doublecar-9/imgs/", "startFrame": 1, "endFrame": 299, "nz": 4,
             "ext": "tif", "anno_path": "doublecar-9/groundtruth_rect.txt", "object_class": "person"},
            {"name": "electriccar-6", "path": "electriccar-6/imgs/", "startFrame": 1, "endFrame": 479, "nz": 4,
             "ext": "tif", "anno_path": "electriccar-6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human-18", "path": "human-18/imgs/", "startFrame": 1, "endFrame": 200, "nz": 4, "ext": "tif",
             "anno_path": "human-18/groundtruth_rect.txt", "object_class": "person"},
            {"name": "human-19", "path": "human-19/imgs/", "startFrame": 1, "endFrame": 143, "nz": 4, "ext": "tif",
             "anno_path": "human-19/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-0", "path": "motorcycle-0/imgs/", "startFrame": 1, "endFrame": 153, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-0/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-3", "path": "motorcycle-3/imgs/", "startFrame": 1, "endFrame": 98, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-5", "path": "motorcycle-5/imgs/", "startFrame": 1, "endFrame": 1703, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-5/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-6", "path": "motorcycle-6/imgs/", "startFrame": 1, "endFrame": 274, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-6/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-7", "path": "motorcycle-7/imgs/", "startFrame": 1, "endFrame": 372, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-7/groundtruth_rect.txt", "object_class": "person"},
            {"name": "motorcycle-8", "path": "motorcycle-8/imgs/", "startFrame": 1, "endFrame": 227, "nz": 4,
             "ext": "tif", "anno_path": "motorcycle-8/groundtruth_rect.txt", "object_class": "person"},
            {"name": "person-2", "path": "person-2/imgs/", "startFrame": 1, "endFrame": 100, "nz": 4, "ext": "tif",
             "anno_path": "person-2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "person-3", "path": "person-3/imgs/", "startFrame": 1, "endFrame": 106, "nz": 4, "ext": "tif",
             "anno_path": "person-3/groundtruth_rect.txt", "object_class": "person"},
            {"name": "triple-2", "path": "triple-2/imgs/", "startFrame": 1, "endFrame": 50, "nz": 4, "ext": "tif",
             "anno_path": "triple-2/groundtruth_rect.txt", "object_class": "person"},
            {"name": "triple-4", "path": "triple-4/imgs/", "startFrame": 1, "endFrame": 199, "nz": 4, "ext": "tif",
             "anno_path": "triple-4/groundtruth_rect.txt", "object_class": "person"}
        ]
        return sequence_info_list
