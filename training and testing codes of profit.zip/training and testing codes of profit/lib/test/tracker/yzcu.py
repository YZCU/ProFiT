import math
from lib.models.yzcu import build_yzcu
from lib.test.tracker.basetracker import BaseTracker
import torch
from lib.test.tracker.vis_utils import gen_visualization
from lib.test.utils.hann import hann2d
from lib.train.data.processing_utils import sample_target
import cv2
import os
from lib.test.tracker.data_utils import Preprocessor
from lib.utils.box_ops import clip_box
from lib.utils.ce_utils import generate_mask_cond
import numpy as np
from filterpy.kalman import KalmanFilter
class yzcu(BaseTracker):
    def __init__(self, params, dataset_name):
        super(yzcu, self).__init__(params)
        network = build_yzcu(params.cfg, training=False)
        network.load_state_dict(torch.load(self.params.checkpoint, map_location='cpu')['net'], strict=True)
        self.cfg = params.cfg
        self.network = network.cuda()
        self.network.eval()
        self.preprocessor = Preprocessor()
        self.state = None
        self.feat_sz = self.cfg.TEST.SEARCH_SIZE // self.cfg.MODEL.BACKBONE.STRIDE
        self.output_window = hann2d(torch.tensor([self.feat_sz, self.feat_sz]).long(), centered=True).cuda()
        self.debug = params.debug
        self.use_visdom = params.debug
        self.frame_id = 0
        self.save_all_boxes = params.save_all_boxes
        self.z_dict1 = {}
        self.tgt_all = []
    def nihe(self, x):
        degree = 2
        coefficients = np.polyfit(range(len(x)), x, degree)
        polynomial = np.poly1d(coefficients)
        predicted_x_21 = polynomial(len(x))
        return predicted_x_21
    def kf(self, a):
        kf = KalmanFilter(dim_x=4, dim_z=2)
        dt = 1.0
        kf.F = np.array([[1, 0, dt, 0],
                         [0, 1, 0, dt],
                         [0, 0, 1, 0],
                         [0, 0, 0, 1]])
        kf.H = np.array([[1, 0, 0, 0],
                         [0, 1, 0, 0]])
        kf.Q = np.eye(4) * 0.1
        kf.R = np.eye(2) * 10
        kf.x = np.array([a[0][0], a[0][1], 0, 0])
        for i in range(1, len(a)):
            kf.predict()
            kf.update(a[i])
        pre_point = kf.x[:2]
        return pre_point
    def compute_apmax(self, a):
        fz = np.square(np.max(a) - np.min(a))
        fm = np.mean(np.square(a - np.min(a)))
        apmax = np.max(a) * (fz / fm)
        return apmax
    def initialize(self, image, info: dict):
        z_patch_arr, resize_factor, z_amask_arr = sample_target(image, info['init_bbox'], self.params.template_factor,
                                                                output_sz=self.params.template_size)
        self.z_patch_arr = z_patch_arr
        template = self.preprocessor.process(z_patch_arr, z_amask_arr)
        with torch.no_grad():
            self.z_dict1 = template
        self.state = info['init_bbox']
        self.frame_id = 0
        if self.save_all_boxes:
            '''save all predicted boxes'''
            all_boxes_save = info['init_bbox'] * self.cfg.MODEL.NUM_OBJECT_QUERIES
            return {"all_boxes": all_boxes_save}
        self.tgt_all = []
    def track(self, image, info: dict = None, seq_name=[], kfpred_bboxes: list = None):
        H, W, _ = image.shape
        self.frame_id += 1
        x_patch_arr, resize_factor, x_amask_arr = sample_target(image, self.state, self.params.search_factor,
                                                                output_sz=self.params.search_size)
        search = self.preprocessor.process(x_patch_arr, x_amask_arr)
        with torch.no_grad():
            x_dict = search
            out_dict = self.network.forward(
                template=self.z_dict1.tensors, search=x_dict.tensors, training=False, tgt_pre=self.tgt_all)
            self.tgt_all = out_dict['tgt']
        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        apmax = self.compute_apmax(response.cpu().numpy().reshape(16, 16))
        dict_zd = {
            'apple': 0,
        }
        if seq_name[1] in dict_zd:
            T = dict_zd[seq_name[1]]
            print(seq_name[1])
            print(dict_zd[seq_name[1]])
        else:
            T = -1
        if apmax > T:
            pred_boxes = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'])
            pred_boxes = pred_boxes.view(-1, 4)
            pred_box = (pred_boxes.mean(dim=0) * self.params.search_size / resize_factor).tolist()
            if 'msvt' in seq_name[0] or 'mssot' in seq_name[0]:
                self.state = clip_box(self.map_box_back(pred_box, resize_factor), H, W, margin=2)
            else:
                self.state = clip_box(self.map_box_back(pred_box, resize_factor), H, W, margin=10)
        else:
            print(apmax)
            x_list = [x for x, y, w, h in kfpred_bboxes]
            y_list = [y for x, y, w, h in kfpred_bboxes]
            w_list = [w for x, y, w, h in kfpred_bboxes]
            h_list = [h for x, y, w, h in kfpred_bboxes]
            pre_x = self.nihe(x_list)
            pre_y = self.nihe(y_list)
            pre_w = self.nihe(w_list)
            pre_h = self.nihe(h_list)
            pre_x, pre_y, pre_w, pre_h = pre_x, pre_y, pre_w * 1.2, pre_h * 1.2
            self.state = [pre_x, pre_y, pre_w, pre_h]
        if self.debug:
            x1, y1, w, h = self.state
            x1_gt, y1_gt, w_gt, h_gt = info['gt_bbox'].tolist()
            bs_order = [0, 1, 2]
            image = image[:, :, bs_order]
            image_BGR = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            cv2.rectangle(image_BGR, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), color=(0, 255, 0), thickness=1)
            cv2.rectangle(image_BGR, (int(x1_gt), int(y1_gt)), (int(x1_gt + w_gt), int(y1_gt + h_gt)),
                          color=(0, 0, 255), thickness=1)
            position = (10, 30)
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            color = (255, 255, 255)
            thickness = 2
            text = 'id:' + str(self.frame_id)
            cv2.putText(image_BGR, text, position, font, font_scale, color, thickness)
            cv2.imshow(seq_name[1], image_BGR)
            cv2.waitKey(1)
        if self.save_all_boxes:
            '''save all predictions'''
            all_boxes = self.map_box_back_batch(pred_boxes * self.params.search_size / resize_factor, resize_factor)
            all_boxes_save = all_boxes.view(-1).tolist()
            return {"target_bbox": self.state,
                    "all_boxes": all_boxes_save}
        else:
            return {"target_bbox": self.state,
                    "apmax": apmax}
    def map_box_back(self, pred_box: list, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return [cx_real - 0.5 * w, cy_real - 0.5 * h, w, h]
    def map_box_back_batch(self, pred_box: torch.Tensor, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box.unbind(-1)
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return torch.stack([cx_real - 0.5 * w, cy_real - 0.5 * h, w, h], dim=-1)
    def add_hook(self):
        conv_features, enc_attn_weights, dec_attn_weights = [], [], []
        for i in range(12):
            self.network.backbone.blocks[i].attn.register_forward_hook(
                lambda self, input, output: enc_attn_weights.append(output[1])
            )
        self.enc_attn_weights = enc_attn_weights
def get_tracker_class():
    return yzcu
