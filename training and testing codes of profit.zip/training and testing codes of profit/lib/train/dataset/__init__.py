# from .lasot import Lasot
# from .got10k import Got10k
# from .tracking_net import TrackingNet
# from .imagenetvid import ImagenetVID
# from .coco import MSCOCO
# from .coco_seq import MSCOCOSeq
# from .got10k_lmdb import Got10k_lmdb
# from .lasot_lmdb import Lasot_lmdb
# from .imagenetvid_lmdb import ImagenetVID_lmdb
# from .coco_seq_lmdb import MSCOCOSeq_lmdb
# from .tracking_net_lmdb import TrackingNet_lmdb
from .hsi_hotc2020 import hotc2020

from .hsi_hotc2023_nir import hotc2023_nir
from .hsi_hotc2023_rednir import hotc2023_rednir
from .hsi_hotc2023_vis import hotc2023_vis

from .hsi_hotc2024_nir import hotc2024_nir
from .hsi_hotc2024_rednir import hotc2024_rednir
from .hsi_hotc2024_vis import hotc2024_vis

from .hsi_mssot import mssot

from .hsi_msvt import msvt