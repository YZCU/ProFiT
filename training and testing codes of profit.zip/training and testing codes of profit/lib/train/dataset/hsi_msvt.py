import os
import os.path
import numpy as np
import torch
import pandas
import random
from collections import OrderedDict
from .base_video_dataset import BaseVideoDataset
from lib.train.admin import env_settings
from lib.train.data import jpeg4py_loader
from PIL import Image
import cv2
class msvt(BaseVideoDataset):
    def __init__(self, root=None, image_loader=jpeg4py_loader, split=None, seq_ids=None, data_fraction=None):
        root = env_settings().hotc2020_train_dir if root is None else root
        super().__init__('HSI', root, image_loader)
        self.sequence_list = self._get_sequence_list()
        self.sequence_meta_info = self._load_meta_info()
        self.seq_per_class = self._build_seq_per_class()
        self.class_list = list(self.seq_per_class.keys())
        self.class_list.sort()
    def get_name(self):
        return 'hsi_msvt'
    def has_class_info(self):
        return True
    def has_occlusion_info(self):
        return True
    def _load_meta_info(self):
        sequence_meta_info = {s: self._read_meta(os.path.join(self.root, s)) for s in self.sequence_list}
        return sequence_meta_info
    def _read_meta(self, seq_path):
        try:
            with open(os.path.join(seq_path, 'meta_info.ini')) as f:
                meta_info = f.readlines()
            object_meta = OrderedDict({'object_class_name': meta_info[5].split(': ')[-1][:-1],
                                       'motion_class': meta_info[6].split(': ')[-1][:-1],
                                       'major_class': meta_info[7].split(': ')[-1][:-1],
                                       'root_class': meta_info[8].split(': ')[-1][:-1],
                                       'motion_adverb': meta_info[9].split(': ')[-1][:-1]})
        except:
            object_meta = OrderedDict({'object_class_name': None,
                                       'motion_class': None,
                                       'major_class': None,
                                       'root_class': None,
                                       'motion_adverb': None})
        return object_meta
    def _build_seq_per_class(self):
        seq_per_class = {}
        for i, s in enumerate(self.sequence_list):
            object_class = self.sequence_meta_info[s]['object_class_name']
            if object_class in seq_per_class:
                seq_per_class[object_class].append(i)
            else:
                seq_per_class[object_class] = [i]
        return seq_per_class
    def get_sequences_in_class(self, class_name):
        return self.seq_per_class[class_name]
    def _get_sequence_list(self):
        dir_list = os.listdir(self.root)
        return dir_list
    def _read_bb_anno(self, seq_path):
        bb_anno_file = os.path.join(seq_path, "groundtruth_rect.txt")
        gt = np.loadtxt(bb_anno_file, dtype=np.float, delimiter=',')
        return torch.tensor(gt)
    def _read_target_visible(self, seq_path):
        bb_anno_file = os.path.join(seq_path, "groundtruth_rect.txt")
        gt = np.loadtxt(bb_anno_file, dtype=np.float, delimiter=',')
        target_visible = torch.ByteTensor([1 for _ in range(len(gt))])
        visible_ratio = torch.ByteTensor([1 for _ in range(len(gt))]).float()
        return target_visible, visible_ratio
    def _get_sequence_path(self, seq_id):
        return os.path.join(self.root, self.sequence_list[seq_id])
    def get_sequence_info(self, seq_id):
        seq_path = self._get_sequence_path(seq_id)
        bbox = self._read_bb_anno(seq_path)
        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible, visible_ratio = self._read_target_visible(seq_path)
        visible = visible & valid.byte()
        return {'bbox': bbox, 'valid': valid, 'visible': visible, 'visible_ratio': visible_ratio}
    def _get_frame_path(self, seq_path, frame_id):
        return os.path.join(seq_path, 'imgs', '{:04}.tif'.format(frame_id + 1))
    def _X2Cube(self, img, bands=25, skips=[5, 5]):
        B = skip = skips
        img = np.asarray(img)
        M, N = img.shape
        col_extent = N - B[1] + 1
        row_extent = M - B[0] + 1
        start_idx = np.arange(B[0])[:, None] * N + np.arange(B[1])
        didx = M * N * np.arange(1)
        start_idx = (didx[:, None] + start_idx.ravel()).reshape((-1, B[0], B[1]))
        offset_idx = np.arange(row_extent)[:, None] * N + np.arange(col_extent)
        out = np.take(img, start_idx.ravel()[:, None] + offset_idx[::skip[0], ::skip[1]].ravel())
        out = np.transpose(out)
        img = out.reshape(M // skip[0], N // skip[1], bands)
        img = img.astype(np.float32)
        channel_mean = np.mean(img, axis=(0, 1))
        if True:
            channel_max = min(channel_mean.mean() * 3, 511)
            img[img > channel_max] = channel_max
        channel_max = np.where(channel_max == 0, 1, channel_max)
        img /= channel_max
        img *= 255
        img = img.astype(np.uint8)
        img_fc = img[:, :, np.linspace(0, bands - 1, 5, dtype=int)[1:4]]
        img_hsi = img[:, :, np.linspace(0, bands - 1, 15, dtype=int)]
        fused_img = cv2.merge((img_fc, img_hsi))
        return fused_img
    def _get_frame(self, hsi_path, frame_id):
        hsi_path = self._get_frame_path(hsi_path, frame_id)
        hsi_image = Image.open(hsi_path)
        hsi_image = self._X2Cube(hsi_image, bands=25, skips=[5, 5])
        return hsi_image
    def get_class_name(self, seq_id):
        obj_meta = self.sequence_meta_info[self.sequence_list[seq_id]]
        return obj_meta['object_class_name']
    def get_frames(self, seq_id, frame_ids, anno=None):
        seq_path = self._get_sequence_path(seq_id)
        obj_meta = self.sequence_meta_info[self.sequence_list[seq_id]]
        frame_list = [self._get_frame(seq_path, f_id) for f_id in frame_ids]
        if anno is None:
            anno = self.get_sequence_info(seq_id)
        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]
        return frame_list, anno_frames, obj_meta
