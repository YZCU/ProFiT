import torch
from torch import nn
import timm
import math
class Adapter(nn.Module):
    def __init__(self, dim, mlp_ratio=0.125, act_layer=nn.GELU, skip_connect=False):
        super().__init__()
        self.skip_connect = skip_connect
        D_hidden_features = int(dim * mlp_ratio)
        self.act = act_layer()
        self.down = nn.Linear(dim, D_hidden_features)
        self.up = nn.Linear(D_hidden_features, dim)
        nn.init.zeros_(self.down.weight)
        nn.init.zeros_(self.down.bias)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)
    def forward(self, x, scale=0.25):
        xs = self.down(x)
        xs = self.act(xs)
        xs = self.up(xs)
        if self.skip_connect:
            x = x + scale * xs
        else:
            x = scale * xs
        return x
if __name__ == "__main__":
    x = torch.randn([32, 320, 768])
    dim = 768
    adapter = Adapter(dim, skip_connect=False)
    out = adapter(x)
    print(out.shape)
